from telegram.ext import Application, MessageHandler, filters
from telegram import ReplyKeyboardMarkup, InputMediaPhoto
from BOT_TOKEN import BOT_TOKEN
from Bot_DB import BOT_DATA_BASE
from Bot_Simple_Prases import SIMPLE_PRASES
from telegram.ext import CommandHandler
from Theory_DB import theory
from Graphics_DB import graphics
from Bot_Simple_Prases import SIMPLE_PRASES
import time, sqlite3, requests, aiohttp, config
from random import choice, randint
from Weather_API_TOKEN import WEATHER_API_KEY
from JOKES_DB import JOKES

current_theme = ''
is_in_task = [False, '', 0]
d = {'logarithms': range(1, 4), 'exponents': range(4, 7), 'derivatives': range(7, 10), 'probability': range(10, 13),
     'stereometry': range(13, 16), 'trigonometry': range(16, 19)}
con = sqlite3.connect('DATA/DB_tasks/tasks_db.sqlite')
cur = con.cursor()

TIMER = 0

rk_start = [['/commands', '/maths']]
rk_commands = [['/comm_list', '/back_start']]
rk_math = [['/algebra', '/stereometry', '/back_start']]
rk_algebra = [['/logarithms', '/exponents', '/derivatives'], ['/probability', '/trigonometry', '/back_math']]
rk_logarithms = [['/definition', '/properties', '/graphs'], ['/equations', '/tasks', '/back_algebra']]
rk_exponents = [['/definition', '/properties', '/graphs'], ['/differentiating', '/tasks', '/back_algebra']]
rk_derivatives = [['/derivs', '/integral', '/formulas'], ['/min_max', '/tasks', '/back_algebra']]
rk_probability = [['/definition', '/complex_prob', '/coin', '/dice'], ['/games', '/shooter', '/boxes', '/production'],
                  ['/lines', '/tasks', '/back_algebra']]
rk_trigonometry = [['/definition', '/circle', '/equations'],
                   ['/graphs', '/formulas', '/tasks', '/back_algebra']]
rk_stereometry = [['/definition', '/plain', '/simple'], ['/sections', '/complex', '/facts'],
                  ['/trial_task', '/tasks', '/back_math']]
mu_start = ReplyKeyboardMarkup(rk_start, one_time_keyboard=False)
mu_commands = ReplyKeyboardMarkup(rk_commands, one_time_keyboard=False)
mu_maths = ReplyKeyboardMarkup(rk_math, one_time_keyboard=False)
mu_stereometry = ReplyKeyboardMarkup(rk_stereometry, one_time_keyboard=False)
mu_algebra = ReplyKeyboardMarkup(rk_algebra, one_time_keyboard=False)
mu_logarithms = ReplyKeyboardMarkup(rk_logarithms, one_time_keyboard=False)
mu_exponents = ReplyKeyboardMarkup(rk_exponents, one_time_keyboard=False)
mu_derivatives = ReplyKeyboardMarkup(rk_derivatives, one_time_keyboard=False)
mu_probability = ReplyKeyboardMarkup(rk_probability, one_time_keyboard=False)
mu_trigonometry = ReplyKeyboardMarkup(rk_trigonometry, one_time_keyboard=False)


async def start(update, context):
    await update.message.reply_text('Вас приветствует искусственный интеллект MathSageAi. Что бы вы хотели сделать?',
                                    reply_markup=mu_start)


async def commands(update, context):
    await update.message.reply_text("Для работы бота напиши расскажи о ... / что такое ... / посчитай ..."
                                    " Нажми на /comm_list, чтобы получить информацию о командах!")


def remove_job_if_exists(name, context):
    """Удаляем задачу по имени.
    Возвращаем True если задача была успешно удалена."""
    current_jobs = context.job_queue.get_jobs_by_name(name)
    if not current_jobs:
        return False
    for job in current_jobs:
        job.schedule_removal()
    return True

async def set_timer(timer, update, context):
    """Добавляем задачу в очередь"""
    chat_id = update.effective_message.chat_id
    # Добавляем задачу в очередь
    # и останавливаем предыдущую (если она была)
    job_removed = remove_job_if_exists(str(chat_id), context)
    context.job_queue.run_once(task, TIMER, chat_id=chat_id, name=str(chat_id), data=TIMER)

    text = f'Вернусь через 5 с.!'
    if job_removed:
        text += ' Старая задача удалена.'
    await update.effective_message.reply_text(text)


async def task(context):
    await context.bot.send_message(context.job.chat_id, text=f'КУКУ! {TIMER}c. прошли!')


async def unset(update, context):
    chat_id = update.message.chat_id
    job_removed = remove_job_if_exists(str(chat_id), context)
    text = 'Таймер отменен!' if job_removed else 'У вас нет активных таймеров'
    await update.message.reply_text(text)




async def geocoder(update, context):
    context2 = update.message.text.split()[1]
    geocoder_uri = "http://geocode-maps.yandex.ru/1.x/"
    response = await get_response(geocoder_uri, params={
        "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
        "format": "json",
        "geocode": context2
    })

    toponym = response["response"]["GeoObjectCollection"][
        "featureMember"][0]["GeoObject"]
    ll, spn = get_ll_spn(toponym)

    static_api_request = f"http://static-maps.yandex.ru/1.x/?ll={ll}&spn={spn}&l=map"
    await context.bot.send_photo(
        update.message.chat_id, 
        static_api_request,
        caption="Нашёл:"
    )


def get_ll_spn(toponym):
    toponym_coodrinates = toponym["Point"]["pos"]
    toponym_longitude, toponym_lattitude = toponym_coodrinates.split(" ")

    ll = ",".join([toponym_longitude, toponym_lattitude])

    envelope = toponym["boundedBy"]["Envelope"]

    l, b = envelope["lowerCorner"].split(" ")
    r, t = envelope["upperCorner"].split(" ")

    dx = abs(float(l) - float(r)) / 2.0
    dy = abs(float(t) - float(b)) / 2.0

    span = f"{dx},{dy}"
    return ll, span


async def get_response(url, params):
    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params) as resp:
            return await resp.json()


async def tasks(update, context):
    global is_in_task
    if not current_theme:
        await update.message.reply_text(f"Выберите тему.")
    elif not is_in_task[0]:
        t = choice(d[current_theme])
        task, answer, image = cur.execute(f"""SELECT t.task, t.answer, t.images_link FROM
                                          Tasks_Data t WHERE t.id = {t}""").fetchone()
        if image != '-':
            await context.bot.send_photo(update.message.chat_id, photo=open(f'DATA/DB_tasks/{image}', 'rb'),
                                         caption=f"Задача №{t}. {task}")
        else:
            await update.message.reply_text(f"Задача №{t}. {task}")
        is_in_task = [True, answer, t]
    else:
        await update.message.reply_text(f"Чтобы решить следующую задачу, дайте ответ на эту.")


async def definition(update, context):
    if not current_theme:
        await update.message.reply_text("Не могу понять, о каком определении рассказать. Сначала выберите тему.")
    else:
        if theory[current_theme]['definition'][1]:
            await context.bot.send_photo(update.message.chat_id, photo=theory[current_theme]['definition'][1],
                                         caption=theory[current_theme]['definition'][0])
        else:
            await update.message.reply_text(theory[current_theme]['definition'][0])


async def graphs(update, context):
    if not current_theme:
        await update.message.reply_text("Не могу понять, о каких графиках рассказать. Сначала выберите тему.")
    else:
        await context.bot.send_media_group(chat_id=update.message.chat_id, media=graphics[current_theme])


async def properties(update, context):
    if not current_theme:
        await update.message.reply_text("Не могу понять, о каких свойствах рассказать. Сначала выберите тему.")
    else:
        if theory[current_theme]['properties'][1]:
            await context.bot.send_photo(update.message.chat_id, photo=theory[current_theme]['properties'][1],
                                         caption=theory[current_theme]['properties'][0])
        else:
            await update.message.reply_text(theory[current_theme]['properties'][0])


async def equations(update, context):
    if not current_theme:
        await update.message.reply_text("Не могу понять, о каких уравнениях рассказать. Сначала выберите тему.")
    else:
        await context.bot.send_photo(update.message.chat_id, photo=theory[current_theme]['equations'][1],
                                     caption=theory[current_theme]['equations'][0])


async def formulas(update, context):
    if not current_theme:
        await update.message.reply_text("Не могу понять, о каких формулах рассказать. Сначала выберите тему.")
    else:
        await context.bot.send_photo(update.message.chat_id, photo=theory[current_theme]['formulas'][1],
                                         caption=theory[current_theme]['formulas'][0])


async def differentiating(update, context):
    await update.message.reply_text(theory['exponents']['differentiating'])


async def derivs(update, context):
    await update.message.reply_text(theory['derivatives']['derivative'][0])
    await context.bot.send_photo(update.message.chat_id, photo=theory['derivatives']['derivative'][1])


async def integral(update, context):
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['derivatives']['integral'])


async def min_max(update, context):
    await update.message.reply_text(theory['derivatives']['min_max'])


async def complex_prob(update, context):
    await update.message.reply_text(theory['probability']['complex_prob'])


async def coin(update, context):
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['probability']['coin'])


async def dice(update, context):
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['probability']['dice'])


async def games(update, context):
    await update.message.reply_text(theory['probability']['games'])


async def shooter(update, context):
    await update.message.reply_text(theory['probability']['shooter'])


async def boxes(update, context):
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['probability']['box'])


async def production(update, context):
    await update.message.reply_text(theory['probability']['production'])


async def lines(update, context):
    await update.message.reply_text(theory['probability']['lines'])


async def circle(update, context):
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['trigonometry']['circle'])


async def plain(update, context):
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['stereometry']['plain'])


async def simple(update, context):
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['stereometry']['simple'])


async def sections(update, context):
    await update.message.reply_text(theory['stereometry']['sdl'][0])
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['stereometry']['sdl'][1:])


async def complex(update, context):
    await update.message.reply_text(theory['stereometry']['complex'][0])
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['stereometry']['complex'][1:])


async def facts(update, context):
    await update.message.reply_text(theory['stereometry']['facts'][0])
    await context.bot.send_media_group(chat_id=update.message.chat_id, media=theory['stereometry']['facts'][1:])


async def trial_task(update, context):
    await context.bot.send_photo(update.message.chat_id, photo=theory['stereometry']['ttask'][1],
                                 caption=theory['stereometry']['ttask'][0])


async def math(update, context):
    global current_theme
    current_theme = ''
    await update.message.reply_text("Выберите, о чём хотите узнать - об алгебре или стереометрии?",
                                    reply_markup=mu_maths)


async def algebra(update, context):
    global current_theme
    current_theme = ''
    await update.message.reply_text("Выберите раздел!\n1.Логарифмы\n2.Показательные и степенные"
                                    "\n3.Производная и интеграл\n4.Теория вероятности\n5.Тригонометрия",
                                    reply_markup=mu_algebra)


async def logarithms(update, context):
    global current_theme
    current_theme = 'logarithms'
    await update.message.reply_text("Выберите тему:", reply_markup=mu_logarithms)


async def exponents(update, context):
    global current_theme
    current_theme = 'exponents'
    await update.message.reply_text("Выберите тему:", reply_markup=mu_exponents)


async def derivatives(update, context):
    global current_theme
    current_theme = 'derivatives'
    await update.message.reply_text("Выберите тему:", reply_markup=mu_derivatives)


async def probability(update, context):
    global current_theme
    current_theme = 'probability'
    await update.message.reply_text("Выберите тему:", reply_markup=mu_probability)


async def trigonometry(update, context):
    global current_theme
    current_theme = 'trigonometry'
    await update.message.reply_text("Выберите тему:", reply_markup=mu_trigonometry)


async def stereometry(update, context):
    global current_theme
    current_theme = 'stereometry'
    await update.message.reply_text("Выберите тему:", reply_markup=mu_stereometry)


async def date_command(update, context):
    await update.message.reply_text(f"Текущая дата: {time.asctime().split()[1:3]}")


async def time_command(update, context):
    await update.message.reply_text(f"Текущее время: {time.asctime().split()[3]}")


async def Message_Handler(update, context):
    global is_in_task
    message = update.message.text.lower()
    if is_in_task[0]:
        if message.strip() == is_in_task[1]:
            await update.message.reply_text('Верно! Вы молодцы!')
            cur.execute(f'UPDATE Tasks_Data SET is_solved = "True" WHERE ID = {is_in_task[2]}')
            con.commit()
            is_in_task = [False, '', 0]
        else:
            await update.message.reply_text('Неправильно, попробуйте позже.')
            is_in_task = [False, '', 0]
    else:
        if message in SIMPLE_PRASES:
            await update.message.reply_text(SIMPLE_PRASES[message])
        elif 'поставь таймер на' in message:
            set_timer(int(message.split()[3]))
        elif 'покажи' in message:
            await geocoder(update, context)
        elif 'погода в' in message:
            code_to_smile = {
                "Clear": "Ясно \U00002600",
                "Clouds": "Облачно \U00002601",
                "Rain": "Дождь \U00002614",
                "Drizzle": "Дождь \U00002614",
                "Thunderstorm": "Гроза \U000026A1",
                "Snow": "Снег \U0001F328",
                "Mist": "Туман \U0001F32B"
            }

            try:
                r = requests.get(
                    f"http://api.openweathermap.org/data/2.5/weather?q={message.split()[2]}&appid={WEATHER_API_KEY}&units=metric"
                )
                data = r.json()

                city = data["name"]
                cur_weather = data["main"]["temp"]

                weather_description = data["weather"][0]["main"]
                if weather_description in code_to_smile:
                    wd = code_to_smile[weather_description]
                else:
                    wd = "Посмотри в окно, не пойму что там за погода!"

                humidity = data["main"]["humidity"]
                pressure = data["main"]["pressure"]
                wind = data["wind"]["speed"]
                sunrise_timestamp = datetime.datetime.fromtimestamp(data["sys"]["sunrise"])
                sunset_timestamp = datetime.datetime.fromtimestamp(data["sys"]["sunset"])
                length_of_the_day = datetime.datetime.fromtimestamp(data["sys"]["sunset"]) - datetime.datetime.fromtimestamp(
                    data["sys"]["sunrise"])

                await update.message.reply_text(f"***{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}***\n"
                      f"Погода в городе: {city}\nТемпература: {cur_weather}C° {wd}\n"
                      f"Влажность: {humidity}%\nДавление: {pressure} мм.рт.ст\nВетер: {wind} м/с\n"
                      f"Восход солнца: {sunrise_timestamp}\nЗакат солнца: {sunset_timestamp}\nПродолжительность дня: {length_of_the_day}\n"
                      f"***Хорошего дня!***"
                      )

            except:
                await update.message.reply_text("\U00002620 Проверьте название города \U00002620")
        elif 'расскажи шутку' in message or 'расскажи анекдот' in message:
            await update.message.reply_text(choice(JOKES))
        elif 'брось кубик на' in message:
            try:
                await update.message.reply_text(f'Выпало число - {randint(1, int(message.split()[-1]))}')
            except:
                await update.message.reply_text('Извините, но у нас не получилось бросить кубик')
        elif 'посчитай' in message:
            try:
                await update.message.reply_text(eval(''.join(message.split()[1:])))
            except Exception:
                await update.message.reply_text('Извините, но вы указали неверный пример')
        elif 'время' in message:
            await update.message.reply_text(f"Текущее время: {''.join(time.asctime().split()[3])}")
        elif 'дата' in message or 'день' in message:
            await update.message.reply_text(f"Текущая дата: {time.asctime().split()[1]} {time.asctime().split()[2]}")
        elif 'расскажи о' in message or 'что такое' in message:
            if len(message.split()) > 2:
                if len(message.split()) == 3:
                    search_word = message.split()[2]
                    for i in range(0, len(search_word)):
                        if search_word in BOT_DATA_BASE.keys():
                            await update.message.reply_text(BOT_DATA_BASE[search_word])
                            break
                        search_word = search_word[:-1]
                    else:
                        await update.message.reply_text('Извините, по вашему запросу ничего не нашлось.')
            else:
                await update.message.reply_text('Извините, но я не понял, что именно вы хотите узнать.'
                                                ' Повторите запрос.')
        else:
            await update.message.reply_text('Извините, я вас не понял. Повторите запрос.')


def main():
    application = Application.builder().token(BOT_TOKEN).build()
    text_handler = MessageHandler(filters.TEXT & ~filters.COMMAND, Message_Handler)
    application.add_handler(text_handler)

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("maths", math))
    application.add_handler(CommandHandler("commands", commands))
    application.add_handler(CommandHandler("date", date_command))
    application.add_handler(CommandHandler("time", time_command))
    
    application.add_handler(CommandHandler("back_start", start))
    application.add_handler(CommandHandler("back_math", math))
    application.add_handler(CommandHandler("back_algebra", algebra))
    application.add_handler(CommandHandler("algebra", algebra))
    application.add_handler(CommandHandler("stereometry", stereometry))
    
    application.add_handler(CommandHandler("logarithms", logarithms))
    application.add_handler(CommandHandler("exponents", exponents))
    application.add_handler(CommandHandler("derivatives", derivatives))
    application.add_handler(CommandHandler("probability", probability))
    application.add_handler(CommandHandler("trigonometry", trigonometry))
    
    application.add_handler(CommandHandler("definition", definition))
    application.add_handler(CommandHandler("graphs", graphs))
    application.add_handler(CommandHandler("tasks", tasks))
    application.add_handler(CommandHandler("properties", properties))
    application.add_handler(CommandHandler("equations", equations))
    application.add_handler(CommandHandler("formulas", formulas))
    
    application.add_handler(CommandHandler("differentiating", differentiating))
    application.add_handler(CommandHandler("derivs", derivs))
    application.add_handler(CommandHandler("integral", integral))
    application.add_handler(CommandHandler("min_max", min_max))
    application.add_handler(CommandHandler("complex_prob", complex_prob))
    
    application.add_handler(CommandHandler("coin", coin))
    application.add_handler(CommandHandler("dice", dice))
    application.add_handler(CommandHandler("games", games))
    application.add_handler(CommandHandler("shooter", shooter))
    application.add_handler(CommandHandler("boxes", boxes))
    
    application.add_handler(CommandHandler("production", production))
    application.add_handler(CommandHandler("lines", lines))
    application.add_handler(CommandHandler("circle", circle))
    application.add_handler(CommandHandler("plain", plain))
    application.add_handler(CommandHandler("simple", simple))
    
    application.add_handler(CommandHandler("sections", sections))
    application.add_handler(CommandHandler("complex", complex))
    application.add_handler(CommandHandler("facts", facts))
    application.add_handler(CommandHandler("trial_task", trial_task))

    application.run_polling()


if __name__ == '__main__':
    main()
